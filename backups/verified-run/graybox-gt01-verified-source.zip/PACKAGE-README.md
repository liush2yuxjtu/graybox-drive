# GT01 verified local candidate

The dist assets passed the complete project verification entry. Source hashes are in manifest.json.

Serve dist with a local HTTP server to play. play-gt01.html is the portable preview generated from the same assets, with the sky embedded and the chase camera selected. Its real keyboard, map, camera, pause and narrow-screen smoke test is included. File-URL navigation is restricted on the validation host, so the preview was tested over loopback HTTP.

To reproduce: install Node, Java 17+, Python and the pinned packages from package-lock.json and tests/requirements-verify.txt; install Playwright Chromium, then run .venv/bin/python tests/verify.py. DRIVE_CHROMIUM_PATH can select an installed compatible browser.

This package is a local candidate. It does not establish physical Android/iPhone performance, photographic concept fidelity, GitHub Actions success or public deployment.
